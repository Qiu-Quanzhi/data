from os.path import abspath, basename
from os import walk
dir = abspath(__file__).replace(f"{basename(__file__)}", '')

array_consts = []
remove_consts = []

for dirpath, dirnames, filenames in walk(dir):
    for filename in [f for f in filenames if f.endswith(".mcfunction")]:
        file = open(f"{dirpath}/{filename}", "r", encoding = 'utf-8')
        try:
            for line_number, line in enumerate(file, start=1):
                try:
                    if line.endswith(" const") or line.endswith(" const\n"):
                        array = line.split()
                        num = array[-2][1:]
                        if array[-2].startswith("#") and num.lstrip('-').isnumeric(): # isinstance
                            if not int(num) in array_consts:
                                array_consts.append(int(num))
                    else:
                        array = line.split()
                        if array[-4] == "set" and array[-2] == "const" and array[-3].startswith("#") and array[-3][1:].lstrip('-').isnumeric():
                            remove_consts.append(int(array[-3][1:]))
                except:
                    True
        except:
            True

array_consts = [f for f in array_consts if not f in remove_consts]
array_consts = sorted(array_consts)


if array_consts:
    file = open(f"{dir}/consts.mcfunction", "w", encoding='utf-8')
    for const in array_consts:
        file.write(f"scoreboard players set #{const} const {const}\n")
    file.close()