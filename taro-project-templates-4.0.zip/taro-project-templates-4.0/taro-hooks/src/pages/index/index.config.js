export default {
  navigationBarTitleText: 'Taro-hooks',
  enableShareAppMessage: true,
};
