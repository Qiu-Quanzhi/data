{{#if (includes "Vue" "Vue3" s=framework)}}
// ESLint 检查 .vue 文件需要单独配置编辑器：
// https://eslint.vuejs.org/user-guide/#editor-integrations
{{/if}}
{
  "extends": ["taro/{{ to_lower_case framework }}"]{{#if (eq framework "React") }},
  "rules": {
    "react/jsx-uses-react": "off",
    "react/react-in-jsx-scope": "off"
  }{{/if}}
}
