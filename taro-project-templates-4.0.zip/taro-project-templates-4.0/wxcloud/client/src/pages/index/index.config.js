export default {
  navigationBarTitleText: '云开发 QuickStart'
}
